# 数学怎么帮我们理解 AI 训练：一本给人类读者的教程

> 位置：`Math of AI Textbook/tutorial/`
> 读者：有基本线性代数/概率直觉、但不一定学过学习理论的 AI 研究者和工程师。
> 写法：**纯 Markdown，公式用普通文本/Unicode 写**，不依赖任何数学渲染器；打开就能读。

---

## 0. 这本教程想解决什么问题

你训练一个小模型：目标是一个确定性的函数 `f`，你从它上面采了 `n` 个点，用一个参数化表达式 `g_θ`（`p` 个参数，`p > n`）去拟合，用梯度下降走 `T` 步。训练误差可以降到接近 0，但**验证集上到底好不好？为什么 A 配置好、B 配置差？**

常见回答是经验规律："更深更好/更宽更好/大 lr 不行/小 lr 欠拟合"。但这些规律互相矛盾，换个任务就翻车。

这本教程换一个问法：

> 给定目标函数 `f`、表达式类 `G`、算法 `A`（GD，T 步，lr，初始化），
> **仅用 f 和 G 的性质，能不能算出/界定验证误差？**

答案分三层：

| 层次 | 能做到什么 | 对应文档 |
|---|---|---|
| 已解决 | 线性/核/惰性（lazy）区：验证误差有闭式，可在训练前算 | 02 |
| 有严格界 | 逼近论、n-width 信息下界、稳定性/泛化界 | 04、05 |
| 开放 | 有限宽非线性特征学习、Adam 有限步、分类 CE、bigram 网络的有限 T（bigram 的地板/估计/噪声已可算，见 06 §5.3） | 06、08 |

---

## 1. 五个核心想法（先记住这五句）

1. **训练不是"把参数调到最优"，而是"在无数个能拟合数据的函数里，算法选了哪一个"。**
2. **验证误差 ≈ A + I + O(T) + F**：
   - `A`（approximation）：表达式类根本表达不了的部分；
   - `I`（identification）：算法在数据上选错了函数（隐式偏置 + 有限样本 aliasing）；
   - `O(T)`：T 步还没走到；
   - `F`：验证集/种子的测量噪声。
3. **`p > n` 本身不是变量。** 有效的"容量"是核的有效秩/函数流形的维数，不是参数个数。
4. **在核/惰性区，"T 步后好不好" = 目标函数的能量有多少落在可学窗口 `η λ_j T ≳ 1` 里。** 这是 spectral bias 的精确版本。
5. **本设定里 5 个族没有标签噪声**（univar/mvar/spiral/xor/tabular），所以经典"过拟合噪声"故事不是主体；bigram 例外，它有不可约熵地板。

---

## 2. 阅读路线

### 路线 A：只想快速会判断（1 小时）

1. `00-cheatsheet.md`：一页纸判据
2. `01-what-training-is.md`：问题重述与四项分解
3. `02-exact-case.md`：唯一能精确算的情形
4. `07-case-studies.md`：四道真实题的判读

### 路线 B：想真正理解理论（半天）

1. `00-cheatsheet.md`
2. `01-what-training-is.md`
3. `02-exact-case.md`
4. `03-budget-and-curves.md`：T、lr、学习曲线、plateau、EoS
5. `04-generalization-and-validation.md`：p>n、double descent、验证集噪声
6. `05-function-and-architecture.md`：目标结构、逼近论、n-width、深度/宽度
7. `06-classification-and-bigram.md`：CE、margin、熵地板
8. `07-case-studies.md`
9. `09-how-to-build-answerer.md`：怎么把理论变成自动答题器（可选，偏工程）
10. `08-limits-and-next.md`：理论不能做什么

### 路线 C：只想知道"这套东西够不够解题"

`00-cheatsheet.md` → `07-case-studies.md` → `08-limits-and-next.md`。想自己动手复现答题器再加 `09-how-to-build-answerer.md`。

---

## 3. 文档清单

| 文件 | 回答的问题 |
|---|---|
| `00-cheatsheet.md` | 一页纸：四项分解、谱滤波、判定流程、常见坑 |
| `01-what-training-is.md` | 训练到底在做什么？为什么训练误差为 0 不代表验证好？ |
| `02-exact-case.md` | 线性/核表达式：验证误差怎么精确算？零空间地板、可学窗口 |
| `03-budget-and-curves.md` | 为什么 T 和 lr 决定短预算成败？plateau、EoS、early stopping |
| `04-generalization-and-validation.md` | p>n 为什么不一定坏？double descent 什么时候适用？验证集怎么比才可信？ |
| `05-function-and-architecture.md` | 目标函数的结构如何决定深度/宽度？n-width 和信息极限 |
| `06-classification-and-bigram.md` | 分类和语言模型为什么不能套回归公式？margin 与熵地板 |
| `07-case-studies.md` | 用四道 v1.5 真题演示"先算再比" |
| `08-limits-and-next.md` | 哪些问题数学还没解决？怎么把理论和实测结合？ |
| `09-how-to-build-answerer.md` | 怎么搭理论答题器：切线性化替身、复刻官方协议、在线 JVP/VJP；500 题 83.2% 的实现细节 |

---

## 4. 约定

- 公式都用 `等宽字体` 或普通文本写出，例如：`R_te ≈ A + I + O(T) + F`。
- `≈` 表示"在给定假设下的近似/主项"；`=` 表示定义或严格等式。
- 所有结论都会标注它是 **严格定理 / 上界 / 渐近 / 启发式** 中的哪一类——这是本项目最重要的纪律。
- 想看完整推导和文献，对应到上一级的 `01-formulation.md` … `05-formalization-and-coverage.md`，以及 `notes/`。

---

## 5. 一句话

**数学不能替你训练模型，但它能告诉你：现在这个验证误差是"表达不了"、"选错了"、"没走到"、还是"测不准"；以及换什么最可能有用。** 这本教程就是把这四句话讲清楚。
